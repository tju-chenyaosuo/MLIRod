//
// Created by Stan Wang on 2023/2/4.
//

#ifndef MLIR_FUZZ_EXPSETTING_H
#define MLIR_FUZZ_EXPSETTING_H

enum Config {
  Diverse,

};

inline bool diverse = false;



#endif // MLIR_FUZZ_EXPSETTING_H
